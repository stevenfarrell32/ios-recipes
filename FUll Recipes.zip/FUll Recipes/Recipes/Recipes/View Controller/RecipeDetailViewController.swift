//
//  RecipeDetailViewController.swift
//  Recipes
//
//  Created by Lambda_School_Loaner_151 on 9/7/19.
//  Copyright © 2019 Lambda Inc. All rights reserved.
//

import UIKit

class RecipeDetailViewController: UIViewController {

    var recipe: Recipe? {
        didSet {
           updateViews()
        }
    }
    
    @IBOutlet weak var recipeNameLabel: UILabel!
    @IBOutlet weak var recipeInstructions: UITextView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
        
        
        
    }
    
    func updateViews() -> String {
        <#function body#>
    }


}

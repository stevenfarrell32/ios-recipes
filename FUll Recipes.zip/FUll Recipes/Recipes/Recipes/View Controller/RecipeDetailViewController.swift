//
//  RecipeDetailViewController.swift
//  Recipes
//
//  Created by Lambda_School_Loaner_151 on 9/7/19.
//  Copyright © 2019 Lambda Inc. All rights reserved.
//

import UIKit

class RecipeDetailViewController: UIViewController {

    var recipe: Recipe?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateViews()
    }
    
    @IBOutlet weak var recipeNameLabel: UILabel!
    @IBOutlet weak var recipeInstructions: UITextView!
    
    
    func updateViews() {
        guard let recipe = recipe else {
            return
        }
        recipeNameLabel.text = recipe.name
        recipeInstructions.text = recipe.instructions
    }
    


}

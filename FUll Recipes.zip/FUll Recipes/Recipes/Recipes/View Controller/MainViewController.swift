//
//  MainViewController.swift
//  Recipes
//
//  Created by Lambda_School_Loaner_151 on 9/7/19.
//  Copyright © 2019 Lambda Inc. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {
 
    @IBOutlet weak var searchTextField: UITextField!
    
    var recipesTableViewController: RecipesTableViewController? {
        didSet {
            self.recipesTableViewController?.recipes = filteredRecipes
        }
    }
    
    
    var filteredRecipes: [Recipe] = [] {
        didSet {
            recipesTableViewController?.recipes = self.filteredRecipes
        }
    }
    
    
    
    let networkClient = RecipesNetworkClient()
    var allRecipes: [Recipe] = [] {
        didSet {
            filterRecipes()
        }
    }

    @IBOutlet weak var searchRecipeTextField: UITextField!
   //sends to the main thread, sort of like sending an ambulance to the destination it needs to go
    func filterRecipes() {
        DispatchQueue.main.async {
            guard let searchText = self.searchTextField.text else { return }
            if searchText.isEmpty || searchText == "" {
                self.filteredRecipes = self.allRecipes
            } else {
                self.filteredRecipes = self.allRecipes.filter { $0.name.contains(searchText) || $0.instructions.contains(searchText) }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        networkClient.fetchRecipes { (recipeResult, error) in
            if let error = error {
                print("Error fetching recipes \(error)")
                return
            }
            if let recipeResult = recipeResult {
                self.allRecipes = recipeResult
            }
        }
        // Do any additional setup after loading the view.
    }
    
    @IBAction func searchTextFieldExit(_ sender: Any) {
        resignFirstResponder()
        filterRecipes()
    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "embedBridgeSegue" {
            // go back over this later. This gives the destination a value since we are embedding it
            recipesTableViewController = segue.destination as? RecipesTableViewController
        }
    }
    
}

//
//  MainViewController.swift
//  Recipes
//
//  Created by Lambda_School_Loaner_151 on 9/7/19.
//  Copyright © 2019 Lambda Inc. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {

    @IBOutlet weak var searchRecipeTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func searchTextFieldExit(_ sender: Any) {
    }
    
}
